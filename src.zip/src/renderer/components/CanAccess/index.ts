export {default as CanAccess} from './CanAccess'
