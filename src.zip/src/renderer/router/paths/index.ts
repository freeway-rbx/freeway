export {default as paths} from './paths'
