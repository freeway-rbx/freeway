import {paths} from '@render/router'

function useRoutePaths() {
  return paths
}

export default useRoutePaths
