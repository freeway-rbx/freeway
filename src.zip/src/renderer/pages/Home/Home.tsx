function Home() {
  return (
    <div>
      <h1>
        Hello World! I am Home page!
      </h1>
    </div>
  )
}

export default Home
