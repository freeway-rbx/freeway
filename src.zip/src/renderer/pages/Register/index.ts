export {default as Register} from './Register'
