/**
 * Renderer-only Google Analytics wrapper using gtag.js
 *
 * NOTE: Replace MEASUREMENT_ID below with your Google Analytics Measurement ID (G-XXXXXXXXXX).
 * This implementation calls the global `gtag` function injected in index.html.
 */

const MEASUREMENT_ID_PLACEHOLDER = 'G-31D2KY463B'

export const initAnalytics = (measurementId: string = MEASUREMENT_ID_PLACEHOLDER) => {
  // noop: index.html should include gtag snippet with the correct measurement id.
  // This function exists so app code can call initAnalytics() if desired.
  if (!(window as any).gtag) {
    console.warn('[Analytics] gtag is not available. Make sure index.html includes the gtag.js snippet with your measurement id.')
  }
  else {
    try {
      ;(window as any).gtag('config', measurementId, { send_page_view: false })
    }
    catch (e) {
      console.warn('[Analytics] gtag config failed', e)
    }
  }
}

export const sendAnalyticsEvent = async (event: string, params: Record<string, any> = {}) => {
  try {
    const gtag = (window as any).gtag
    if (typeof gtag !== 'function') {
      console.warn('[Analytics] gtag not found; event not sent:', event, params)
      return
    }
    gtag('event', event, params)
  } 
  catch (error) {
    console.error('[Analytics] Failed to send event:', event, error)
  }
}
