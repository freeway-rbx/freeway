// seconds * minutes * hours * days
export const COOKIE_EXPIRATION_TIME = 60 * 60 * 24 // 1 day
export const TOKEN_COOKIE = 'reactauth.token'
export const REFRESH_TOKEN_COOKIE = 'reactauth.refreshToken'
