export class CreateAssetResultDto {
  assetId: string
  decalId: string
  operationId: string
}
