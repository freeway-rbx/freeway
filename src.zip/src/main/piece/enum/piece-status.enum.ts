export enum PieceStatusEnum {
  queue = 'queue',
  upload = 'upload',
  ok = 'ok',
  error = 'error',
}
