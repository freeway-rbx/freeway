export enum PieceRoleEnum {
  asset = 'asset',
  editable = 'editable',
  virtual = 'virtual',
  draft = 'draft',
}
