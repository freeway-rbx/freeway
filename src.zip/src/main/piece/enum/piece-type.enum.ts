export enum PieceTypeEnum {
  image = 'image',
  mesh = 'mesh',
  meshtexturepack = 'meshtexturepack',
  unknown = 'unknown',
}
