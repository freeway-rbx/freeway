/*
import micromatch from 'micromatch'

const ig = ['_*', '.*', '**!/!*.!(png|jpg|jpeg|gif|obj)', '**!/!(*.*)']

const files = [
  '_something',
  '.something/with/dot.jpg',
  'text.txt',
  '000.jpg',
  '20190728_183838.jpg',
  'another-hello.png',
  'cat-mem.jpeg',
  'cat.jpeg',
  'cat22.jpeg',
  'hello2.png',
  'qqq2',
  'sample-hello.png',
  'sample-hello2 - Copy.png',
  'sample-hello2.png',
  'skull.obj',
  'snapshot.txt',
  'qqq2\\another-hello.png',
  'qqq2\\cat - Copy.jpeg',
]

console.log(files.filter(x => !micromatch.isMatch(x, ig)))

console.log(files.filter(x => !micromatch.isMatch(x, '.*!/!**')))
*/
