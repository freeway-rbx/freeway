/**
 * AnalyticsService (renderer-forwarding shim)
 *
 * This service no longer sends events to Google Analytics from the main process.
 * Instead, it forwards events to renderer windows (webContents) via an IPC message
 * named 'analytics:forward'. The renderer is responsible for calling gtag.
 *
 * This keeps the previous import path and minimal changes elsewhere in main code.
 */

import {Injectable, Logger} from '@nestjs/common'
import {BrowserWindow} from 'electron'

@Injectable()
export class AnalyticsService {
  private readonly logger = new Logger(AnalyticsService.name);

  constructor() {}

  async sendEvent(eventName: string, params: Record<string, any> = {}) {
    try {
      // Forward to all renderer windows
      const wins = BrowserWindow.getAllWindows()
      if (!wins || wins.length === 0) {
        this.logger.warn('No renderer windows available to forward analytics event:', eventName)
        return;
      }
      for (const w of wins) {
        try {
          w.webContents.send('analytics:forward', {eventName, params})
        }
        catch (err) {
          this.logger.warn('Failed to send analytics to a window', err)
        }
      }
      this.logger.log(`Forwarded analytics event: ${eventName}`)
    }
    catch (err) {
      this.logger.error('Analytics forwarding error', err)
    }
  }
}
