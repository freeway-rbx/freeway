declare const __GA_MEASUREMENT_ID__: string
declare const __GA_API_SECRET__: string
declare const __VITE_SENTRY_DSN__: string
